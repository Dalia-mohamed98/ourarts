<?php
namespace Zprint\Template;

interface TemplateSettings {
	public function getTemplateSettings();
}
