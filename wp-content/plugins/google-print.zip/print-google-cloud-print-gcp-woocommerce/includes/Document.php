<?php

namespace Zprint;

class Document extends DocumentBase
{
}
