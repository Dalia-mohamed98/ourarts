<?php

interface WPML_ST_Slug_Translation_Custom_Types_Repository {
	/**
	 * @return WPML_ST_Slug_Custom_Type[]
	 */
	public function get();
}