<?php

interface IWPML_TM_Admin_Section_Factory {

	/**
	 * @return WPML_TM_Admin_Section
	 */
	public function create();
}