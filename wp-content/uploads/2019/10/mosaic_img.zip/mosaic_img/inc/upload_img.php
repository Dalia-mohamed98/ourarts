<html>
    <head>
        <meta name="viewport" content="width=device-width,initial-scale=1">
    </head>
    <body>
        <?php 
        session_start();
        // $_SESSION['message']="";
        ?>
        <form action="img_proc.php" method="post" enctype="multipart/form-data">
            <label>Select your design to upload</label>
            <input type="file" name="fileToUpload" id="fileToUpload" accept="image/*">
            <input type="submit" value="Upload Image" name="submit">
        </form>
        <?php
            if($_SESSION['message'])
                echo $_SESSION['message'];
                $_SESSION['message']="";
        ?>

    </body>
</html>