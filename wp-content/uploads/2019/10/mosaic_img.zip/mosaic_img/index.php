<?php

/**
 * @link              http://our-arts.com
 * @since             1.0.0
 * @package           calc
 *
 * @wordpress-plugin
 * Plugin Name:       img-caclulator
 * Plugin URI:        http://our-arts.com
 * Description:       made by dalia
 * Version:           1.0.0
 * Author:            dalia
 * Author URI:        http://our-arts.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       dalia
 * Domain Path:       /languages
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
/**
 * Check if WooCommerce is active
 * */
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}
////////////////CONSTANTS//////////////////////
define('ASH2OSH_FAW_PAYMENT_METHOD','ash2osh_faw');
//////////////////////////////////////////////

/////////////////includes////////////////////////
require_once 'inc/img_proc';
require_once 'inc/upload_img';

register_activation_hook( __FILE__, 'ash2osh_faw_activate' );
register_deactivation_hook(__FILE__, 'ash2osh_faw_deactivate');

